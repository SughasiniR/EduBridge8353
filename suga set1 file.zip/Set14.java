package suga;

import java.util.Scanner;
public class Set14 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.print("Enter the Cost Price: ");
	    int n1=sc.nextInt();
	    System.out.print("Enter the Selling Price: ");
	    int n2=sc.nextInt();
	    int loss,profit;
	    if(n1>n2)
	    {
	    	System.out.println("It is loss");
	    	loss=n1-n2;
	    	System.out.println("Loss : "+loss);
	    }
	    else if(n2>n1) {
	    	System.out.println("It is profit");
	    	profit=n2-n1;
	    	System.out.println("Profit : "+profit);
	    }
	    else {
	    	System.out.println("There is no loss and no profit");
	    }
	}

}
