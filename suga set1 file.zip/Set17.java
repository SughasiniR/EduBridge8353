package suga;

import java.util.Scanner;
public class Set17 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the year: ");
		int n=sc.nextInt();
		if(n%400==0) {
			System.out.println("It is leap year");
		}
		else if(n%100==0){
			System.out.println("It is century year");
		}
		else if(n%4==0){
			System.out.println("It is leap year");
		}
		else {
			System.out.println("It is not leap year");
		}

	}

}
