package suga;

import java.util.Scanner;
public class Set13 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.print("Enter the quantity: ");
	    int n=sc.nextInt();
	    int total=0;
	    int a;
	    for(int i=0;i<n;i++) {
	    	a=sc.nextInt();
	    	total+=a;
	    }
	    int t=0;
	    if(total>5000) {
	    	t=total*10;
	    	t=t/100;
	    total=total-t;
	    System.out.println("The total amount: "+total);
	    }
	    else {
	    	System.out.println("The total amount: "+total);
	    }
	}

}
