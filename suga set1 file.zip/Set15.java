package suga;

import java.util.Scanner;
public class Set15 {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.print("Enter the Ram age: ");
		int a1=sc.nextInt();
		System.out.print("Enter the Sulabh age: ");
		int a2=sc.nextInt();
		System.out.print("Enter the Ajay age: ");
		int a3=sc.nextInt();
		if(a1<a2 && a1<a3) {
			System.out.println("Ram is the youngest person ");
		}
		else if(a2<a1 && a2<a3) {
			System.out.println("Sulabh is the youngest person ");
		}
		else {
			System.out.println("Ajay is the youngest person ");
		}
	}

}
