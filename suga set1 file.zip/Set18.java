package suga;

import java.util.Scanner;
public class Set18 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Salary: ");
		double n=sc.nextInt();
		double hra,da;
		if(n<1500) {
			hra=n*10;
			hra=hra/100;
			da=n*90;
			da=da/100;
			n=hra+da+n;
			System.out.print("Your gross Salary is "+n);
		}
		else {
			hra=500;
			da=n*98;
			da=da/100;
			n=hra+da+n;
			System.out.print("Your gross Salary is "+n);
		}

	}

}
