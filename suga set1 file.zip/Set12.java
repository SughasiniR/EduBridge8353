package suga;

import java.util.Scanner;
public class Set12{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the value: ");
		int n=sc.nextInt();
		if(n<0) {
			System.out.print("Absolute value is "+(-n));
		}
		else {
			System.out.print("Absolute value is "+n);
		}
	}

}
