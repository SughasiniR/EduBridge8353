package suga;

import java.util.Scanner;
public class Set110 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		float sum=0,a;
		for(int i=1;i<=5;i++) {
			System.out.print("Enter the Subject"+i+" mark :");
			a=sc.nextInt();
			sum+=a;
		}
		
		sum=sum/5;
		if(sum>=60) {
			System.out.print("Student got first division");
		}
		else if(sum>=50 && sum<=59) {
			System.out.print("Student got second division");
		}
		else if(sum>=40 && sum<=49) {
			System.out.print("Student got third division");
		}
		else {
			System.out.print("Fail");
		}
	}
}
