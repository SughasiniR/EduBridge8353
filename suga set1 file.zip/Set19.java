package suga;

import java.util.Scanner;
public class Set19{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the count of calls to calculate bill: ");
		double n=sc.nextDouble();
		double a=0;
		if(n>0 && n<=100) {
			System.out.println("Your bill is Rs.200");
		}
		else if(n>100 && n<=150) {
			a=n-100;
			a=a*0.60;
			a=200+a;
			System.out.println("Your bill is Rs."+a);
		}
		else if(n>150 && n<=200) {
			a=n-150;
			a=a*0.50;
			a+=200+(50*0.60);
			System.out.println("Your bill is Rs."+a);
		}
		else if (n>200){
			a=n-200;
			a=a*0.40;
			a+=200+(50*0.60)+(50*0.50);
			System.out.println("Your bill is Rs."+a);
		}
		else {
			System.out.println("No bill");
		}
	}
}
