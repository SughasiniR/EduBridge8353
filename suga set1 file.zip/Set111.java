package suga;

import java.util.Scanner;
public class Set111 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character: ");
		char c=sc.next().charAt(0);
		int n=(int)c;
		if(c>=65 && c<=90) {
			System.out.print("Character entered is capital letter");
		}
		else if(c>=97 && c<=122) {
			System.out.print("Character entered is small case letter");
		}
		else if(c>=48 && c<=57) {
			System.out.print("Character entered is a digit");
		}
		else {
			System.out.print("Character entered is a special symbol");
		}
	}

}
