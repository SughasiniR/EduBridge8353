package suga;

import java.util.Scanner;
public class Set16 {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.print("Enter the angles : ");
		int total=0;
		for(int i=0;i<3;i++) {
			int a=sc.nextInt();
			total+=a;
		}
		if(total==180) {
			System.out.print("Triangle is valid");
		}
		else System.out.print("Triangle is not valid");
	}
}
